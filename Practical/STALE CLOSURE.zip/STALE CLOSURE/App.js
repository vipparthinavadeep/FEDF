//import MapReduceFilter from "./MapReduceFilter";
//import SimpleMap from "./SimpleMap"
import BuggyTimer from "./BuggyTimer";
import FixedTimer from "./FixTimer";
export default function App() {
  return (
    <div>
      <BuggyTimer />
      <FixedTimer />
           
    </div>
  );
}
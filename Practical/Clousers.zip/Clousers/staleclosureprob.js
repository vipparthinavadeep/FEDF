function Timer() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const id = setInterval(() => {
      // This callback closes over
      // `count` from the FIRST render!
      // It will always be 0. 🐛
      setCount(count + 1);
    }, 1000);
    return () => clearInterval(id);
  }, []); // empty deps → runs once
console.log(count)
}

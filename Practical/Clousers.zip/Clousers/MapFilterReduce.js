// Data
const products = [
  { id: 1, name: 'Keyboard', price: 129, inStock: true },
  { id: 2, name: 'Mouse', price: 59, inStock: false },
  { id: 3, name: 'Monitor', price: 399, inStock: true },
];

// MAP → transform data
const cards = products.map(p => `Product: ${p.name} - ₹${p.price}`);
console.log("MAP result:");
console.log(cards);

// FILTER → get in-stock items
const available = products.filter(p => p.inStock);
console.log("\nFILTER result:");
console.log(available);

// REDUCE → total price
const cartTotal = products
  .filter(p => p.inStock)
  .reduce((sum, p) => sum + p.price, 0);

console.log("\nREDUCE result:");
console.log("Total:", cartTotal);

// ADVANCED REDUCE → convert array to object
const byId = products.reduce((acc, p) => {
  acc[p.id] = p;
  return acc;
}, {});

console.log("\nAdvanced REDUCE (byId):");
console.log(byId);